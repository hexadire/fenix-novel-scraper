/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

import mozilla from "eslint-plugin-mozilla";

export default [
  {
    plugins: { mozilla },

    rules: {
      // Rules from the mozilla plugin
      "mozilla/balanced-listeners": "error",
      "mozilla/no-aArgs": "error",
      "mozilla/var-only-at-top-level": "error",

      // No expressions where a statement is expected
      "no-unused-expressions": "error",

      // Disallow using variables outside the blocks they are defined (especially
      // since only let and const are used, see "no-var").
      "block-scoped-var": "error",

      // Warn about cyclomatic complexity in functions.
      complexity: ["error", { max: 26 }],

      // Maximum depth callbacks can be nested.
      "max-nested-callbacks": ["error", 4],

      // Allow the console API aside from console.log.
      "no-console": ["error", { allow: ["error", "info", "trace", "warn"] }],

      // Disallow fallthrough of case statements, except if there is a comment.
      "no-fallthrough": "error",

      // Disallow use of multiline strings (use template strings instead).
      "no-multi-str": "error",

      // Disallow usage of __proto__ property.
      "no-proto": "error",

      // Disallow use of assignment in return statement. It is preferable for a
      // single line of code to have only one easily predictable effect.
      "no-return-assign": "error",

      // Require use of the second argument for parseInt().
      radix: "error",

      // Require "use strict" to be defined globally in the script.
      strict: ["error", "global"],

      // Disallow Yoda conditions (where literal value comes first).
      yoda: "error",

      // Disallow function or variable declarations in nested blocks
      "no-inner-declarations": "error",
    },
  },
];
